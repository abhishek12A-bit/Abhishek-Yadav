import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:async';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Zymo',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFFC3F261),
        scaffoldBackgroundColor: Colors.black,
        textTheme: GoogleFonts.interTextTheme(
          Theme.of(context).textTheme.apply(
            bodyColor: Colors.white,
            displayColor: Colors.white,
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;

  ChatMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessage> _messages = [];
  bool _isTyping = false;

  final Map<String, String> chatResponses = {
    'book': '''To book a car with Zymo:
1. Choose your preferred vehicle
2. Select the rental duration
3. Complete the verification process
4. Make the payment
Our team will contact you within 2 hours!''',
    'fuel': 'We provide the car with a full tank. During the rental period, you\'ll need to handle refueling. We recommend using the specified fuel type for optimal performance.',
    'cancellation': 'Our cancellation policy is flexible! Cancel 24 hours before pickup for a full refund. Within 24 hours, a small fee may apply.',
    'charge': 'You can charge the vehicle at home using the provided home charging unit. It takes about 6-8 hours for a full charge.',
    'charger': 'Yes! We provide a complimentary home charging unit with every EV rental.',
    'fast': 'Fast charging is available at designated stations. The Nexon EV can charge from 20% to 80% in just 60 minutes!',
    'default': 'I\'m here to help! Could you please rephrase your question or choose from the popular enquiries above?'
  };

  String getResponse(String question) {
    final q = question.toLowerCase();
    if (q.contains('book')) return chatResponses['book']!;
    if (q.contains('fuel')) return chatResponses['fuel']!;
    if (q.contains('cancel')) return chatResponses['cancellation']!;
    if (q.contains('charge') && q.contains('home')) return chatResponses['charge']!;
    if (q.contains('charger')) return chatResponses['charger']!;
    if (q.contains('fast')) return chatResponses['fast']!;
    return chatResponses['default']!;
  }

  void handleSend() {
    if (_messageController.text.trim().isEmpty) return;

    setState(() {
      _messages.add(ChatMessage(
        text: _messageController.text,
        isUser: true,
        timestamp: DateTime.now(),
      ));
      _messageController.clear();
      _isTyping = true;
    });

    Timer(const Duration(seconds: 1), () {
      setState(() {
        _messages.add(ChatMessage(
          text: getResponse(_messages.last.text),
          isUser: false,
          timestamp: DateTime.now(),
        ));
        _isTyping = false;
      });
      _scrollToBottom();
    });
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black87,
        title: Row(
          children: [
            Icon(Icons.directions_car, color: Theme.of(context).primaryColor),
            const SizedBox(width: 8),
            Text(
              'ZYMO',
              style: TextStyle(
                color: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            color: Theme.of(context).primaryColor.withOpacity(0.2),
            height: 1,
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(
                  'Transforming the way India Drives.',
                  style: TextStyle(
                    color: Theme.of(context).primaryColor,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Your Journey Starts Here ✦',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                RichText(
                  text: TextSpan(
                    text: 'Uncover the Ultimate Driving Experience with ',
                    style: const TextStyle(color:Colors.white,fontSize: 24),
                    children: [
                      TextSpan(
                        text: 'ZAI!..',
                        style: TextStyle(
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                _buildPopularEnquiries(),

                const SizedBox(height: 32),
                _buildFAQs(),
              ],
            ),
          ),
          _buildChatInterface(),
        ],
      ),
    );
  }

  Widget _buildPopularEnquiries() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Popular enquiry',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        ...['How can I book a car with Zymo?', 'What about the fuel?', 'What is your cancellation policy?']
            .map((question) => _buildEnquiryCard(question))
            .toList(),
      ],
    );
  }

  Widget _buildEnquiryCard(String question) {
    return Card(
      color: Colors.grey[900],
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(
          color: Theme.of(context).primaryColor.withOpacity(0.2),
        ),
      ),
      child: InkWell(
        onTap: () {
          _messageController.text = question;
          handleSend();
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Text(
                '✦',
                style: TextStyle(
                  color: Theme.of(context).primaryColor,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(child: Text(question)),
            ],
          ),
        ),
      ),
    );
  }



  Widget _buildPriceRow(String label, String amount, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            amount,
            style: TextStyle(
              color: Theme.of(context).primaryColor,
              fontWeight: isTotal ? FontWeight.bold : null,
              fontSize: isTotal ? 18 : null,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFAQs() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'FAQs',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        ...[
          'How do I Charge the vehicle at home?',
          'Will You Provide a Charger?',
          'What if I do FAST Charging?'
        ].map((question) => _buildFAQCard(question)).toList(),
      ],
    );
  }

  Widget _buildFAQCard(String question) {
    return Card(
      color: Colors.grey[900],
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(
          color: Theme.of(context).primaryColor.withOpacity(0.2),
        ),
      ),
      child: InkWell(
        onTap: () {
          _messageController.text = question;
          handleSend();
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(child: Text(question)),
              Icon(
                Icons.keyboard_arrow_down,
                color: Theme.of(context).primaryColor,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChatInterface() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black87,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).primaryColor.withOpacity(0.2),
          ),
        ),
      ),
      child: Column(
        children: [
          Container(
            height: 150,
            padding: const EdgeInsets.all(16),
            child: ListView.builder(
              controller: _scrollController,
              itemCount: _messages.length + (_isTyping ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == _messages.length) {
                  return Row(
                    children: [
                      SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            Theme.of(context).primaryColor,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'ZAI is typing...',
                        style: TextStyle(
                          color: Theme.of(context).primaryColor,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  );
                }

                final message = _messages[index];
                return Align(
                  alignment: message.isUser
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: message.isUser
                          ? Theme.of(context).primaryColor
                          : Colors.grey[900],
                      borderRadius: BorderRadius.circular(12),
                      border: message.isUser
                          ? null
                          : Border.all(
                        color: Theme.of(context).primaryColor.withOpacity(0.2),
                      ),
                    ),
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.75,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          message.text,
                          style: TextStyle(
                            color: message.isUser ? Colors.black : Colors.white,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          TimeOfDay.fromDateTime(message.timestamp)
                              .format(context),
                          style: TextStyle(
                            fontSize: 10,
                            color: message.isUser
                                ? Colors.black54
                                : Colors.grey[400],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: 'Ask ZAI anything about our services...',
                      filled: true,
                      fillColor: Colors.grey[900],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Theme.of(context).primaryColor.withOpacity(0.2),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    ),
                    onSubmitted: (_) => handleSend(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: handleSend,
                  icon: Icon(
                    Icons.send,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}