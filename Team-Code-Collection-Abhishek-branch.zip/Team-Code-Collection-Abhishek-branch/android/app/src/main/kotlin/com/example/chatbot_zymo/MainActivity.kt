package com.example.chatbot_zymo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
